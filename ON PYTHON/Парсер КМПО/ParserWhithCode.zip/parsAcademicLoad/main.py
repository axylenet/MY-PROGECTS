from copy import copy
from openpyxl import load_workbook, Workbook
from openpyxl.styles import NamedStyle, Border, Font, Side, Alignment
from openpyxl.utils import get_column_letter

template_path = "Папка для парсинга/Шаблон.xlsx"
pars_path = "Папка для парсинга/Основная нагрузка.xlsx"

template = load_workbook(template_path)

new_workbook = Workbook()
new_sheet = new_workbook.active

for row in new_sheet.iter_rows():
    for cell in row:
        cell.value = None  # или cell.value = ""

# Копирование данных из шаблона
source_sheet = template[template.sheetnames[0]]
for row in source_sheet.iter_rows(min_row=1, max_row=source_sheet.max_row,
                                  min_col=1, max_col=source_sheet.max_column):
    new_row = []
    for cell in row:
        if 2 <= cell.column <= 21 and 2 <= cell.row <= 5:  # Исключение диапазона B2:U5
            new_row.append(None)
        else:
            new_row.append(cell.value)
    new_sheet.append(new_row)

for row in new_sheet.iter_rows(min_row=7, max_row=18, min_col=2, max_col=21):
    for cell in row:
        cell.value = None

# Копирование стилей
merged_cells = source_sheet.merged_cells.ranges
for row in source_sheet.iter_rows(min_row=1, max_row=source_sheet.max_row,
                                  min_col=1, max_col=source_sheet.max_column):
    for cell in row:
        new_cell = new_sheet.cell(row=cell.row, column=cell.column)
        if cell.has_style:
            new_cell.font = copy(cell.font)
            new_cell.border = copy(cell.border)
            new_cell.fill = copy(cell.fill)
            new_cell.number_format = cell.number_format
            new_cell.alignment = copy(cell.alignment)

# Копирование ширины и высоты ячеек
for i, column in enumerate(source_sheet.columns, start=1):
    new_sheet.column_dimensions[get_column_letter(i)].width = source_sheet.column_dimensions[get_column_letter(i)].width

for row in source_sheet.rows:
    new_sheet.row_dimensions[row[0].row].height = source_sheet.row_dimensions[row[0].row].height

# Копирование стилей из последней строки
last_row = source_sheet.max_row
for col in range(1, source_sheet.max_column + 1):
    new_sheet.cell(row=last_row + 1, column=col)._style = copy(source_sheet.cell(row=last_row, column=col)._style)

# Добавление новой строки для полной нагрузки
new_sheet.cell(row=last_row + 1, value='Полная нагрузка', column=1)
for col in range(2, source_sheet.max_column + 1):
    new_sheet.cell(row=last_row + 1, column=col)._style = copy(source_sheet.cell(row=last_row, column=col)._style)


workbook_pars = load_workbook(pars_path)
sheet = workbook_pars.active

groups_dict = {}
hours_dict = {}

current_row = 3  # Начинаем с третьей строки, так как первые две строки заголовки
teacher_name = None
current_color = None

while True:
    cell_a = sheet.cell(row=current_row, column=1)
    cell_color = cell_a.fill.start_color.index if cell_a.fill.start_color.index else None

    if not cell_a.value:  # Если в столбце A встречается пустая ячейка, прерываем цикл
        break

    if teacher_name is None or current_color is None or current_color != cell_color:
        teacher_name = cell_a.value
        current_color = cell_color


        # Обнуляем списки и переменные
        groups_dict = {}
        hours_dict = {}

        # Обработка новой таблицы
        while True:
            cell_d = sheet.cell(row=current_row, column=4).value
            if not cell_d:  # Если в столбце D встречается пустая ячейка, прерываем цикл для данного преподавателя
                break

            current_subject = cell_d

            cell_i = sheet.cell(row=current_row, column=9).value
            cell_b = sheet.cell(row=current_row, column=2).value

            if cell_i and current_subject:
                if current_subject in groups_dict:
                    groups_dict[current_subject].append(cell_b)
                else:
                    groups_dict[current_subject] = [cell_b]

                if current_subject in hours_dict:
                    hours_dict[current_subject].append(cell_i)
                else:
                    hours_dict[current_subject] = [cell_i]

            current_row += 1

        # Процесс создания новых листов с данными для каждого предмета и сохранения файлов
        start_column = 2
        start_row = 5
        # Создаем стиль для копирования форматирования

        for i, (subject, groups) in enumerate(groups_dict.items(), start=1):
            step = 2
            column_index = start_column

            # Определение длины предмета в соответствии с количеством групп
            end_column = start_column + len(groups) * 2 - 1

            # Заполнение ячеек для названия предмета
            subject_cell = new_sheet.cell(row=4, column=start_column, value=subject)
            for group in groups:
                current_cell = new_sheet.cell(row=start_row, column=column_index, value=group)
                column_index += step

            start_column = end_column + 1


        current_column = 2
        max_columns = sheet.max_column
        previous_values = 0

        while current_column <= max_columns:
            value_above = new_sheet.cell(row=5, column=current_column).value
            if value_above is not None:
                previous_values = 0
                new_sheet.cell(row=6, column=current_column).value = '6' if current_column % 2 == 1 else '5'
                current_column += 1
            else:
                previous_values += 1
                if previous_values >= 2:
                    new_sheet.cell(row=6, column=current_column).value = None
                    break
                else:
                    new_sheet.cell(row=6, column=current_column).value = '6' if current_column % 2 == 1 else '5'
                    current_column += 1


        column_index = 2

        for subject, hours in hours_dict.items():
            step = 2

            for hour in hours:
                current_cell = new_sheet.cell(row=19, column=column_index, value=hour)
                column_index += step

        bold_font = Font(bold=True, name='Times New Roman', size=12)
        thin_border = Border(left=Side(style='thin'),
                             right=Side(style='thin'),
                             top=Side(style='thin'),
                             bottom=Side(style='thin'))
        center_alignment = Alignment(horizontal='center')

        # Применение стилей к нужному диапазону ячеек
        current_column = 2
        max_columns = sheet.max_column
        empty_counter = 0

        for current_column in range(2, max_columns + 1):
            value_above = new_sheet.cell(row=6, column=current_column).value
            if value_above is None:
                empty_counter += 1
            else:
                empty_counter = 0

            if empty_counter >= 2:
                for col in range(2, current_column-1):
                    for row in range(4, 20):
                        new_sheet.cell(row=row, column=col).font = bold_font
                        new_sheet.cell(row=row, column=col).border = thin_border
                        new_sheet.cell(row=row, column=col).alignment = center_alignment
                break

        merge_ranges = {}
        try:
            start_column = 2
            for subject, groups in groups_dict.items():
                if len(groups) > 1:
                    num_cells = len(groups) * 2
                    merge_ranges[subject] = (
                    start_column, start_column + num_cells - 1)  # Сохранение диапазона для каждого предмета
                    start_column += num_cells  # Увеличение стартовой колонки для следующего предмета
                else:
                    num_cells = len(groups) * 2
                    merge_ranges[subject] = (
                    start_column, start_column + 1)  # Сохранение диапазона для каждого предмета
                    start_column += num_cells  # Увеличение стартовой колонки для следующего предмета

            # После заполнения данных объединяем ячейки для предметов

            for subject, merge_range in merge_ranges.items():
                start_col, end_col = merge_range
                start_cell = new_sheet.cell(row=4, column=start_col)
                end_cell = new_sheet.cell(row=4, column=end_col)
                new_sheet.merge_cells(start_cell.coordinate + ':' + end_cell.coordinate)
        except Exception as e:
            print(e)
    else:
        current_row += 1
        teacher_name_cell = new_sheet.cell(row=2, column=2,
                                           value=teacher_name)  # Укажите фамилию преподавателя здесь

        # Объединение ячеек для фамилии преподавателя
        end_col_teacher = min(9,
                              2 + len(teacher_name_cell.value) - 1)  # Определение конечной колонки для фамилии
        end_cell_teacher = new_sheet.cell(row=2, column=end_col_teacher)

        new_sheet.merge_cells(teacher_name_cell.coordinate + ':' + end_cell_teacher.coordinate)
        new_workbook.save(f"{teacher_name}.xlsx")
        new_workbook.close()  # Закрыть книгу после каждого преподавателя

        # Обновление новой книги для следующего преподавателя
        new_workbook = Workbook()
        new_sheet = new_workbook.active

        for row in new_sheet.iter_rows():
            for cell in row:
                cell.value = None  # или cell.value = ""

        # Копирование данных из шаблона
        source_sheet = template[template.sheetnames[0]]
        for row in source_sheet.iter_rows(min_row=1, max_row=source_sheet.max_row,
                                          min_col=1, max_col=source_sheet.max_column):
            new_row = []
            for cell in row:
                if 2 <= cell.column <= 21 and 2 <= cell.row <= 5:  # Исключение диапазона B2:U5
                    new_row.append(None)
                else:
                    new_row.append(cell.value)
            new_sheet.append(new_row)

        for row in new_sheet.iter_rows(min_row=7, max_row=18, min_col=2, max_col=21):
            for cell in row:
                cell.value = None

        # Копирование стилей
        merged_cells = source_sheet.merged_cells.ranges
        for row in source_sheet.iter_rows(min_row=1, max_row=source_sheet.max_row,
                                          min_col=1, max_col=source_sheet.max_column):
            for cell in row:
                new_cell = new_sheet.cell(row=cell.row, column=cell.column)
                if cell.has_style:
                    new_cell.font = copy(cell.font)
                    new_cell.border = copy(cell.border)
                    new_cell.fill = copy(cell.fill)
                    new_cell.number_format = cell.number_format
                    new_cell.alignment = copy(cell.alignment)

        # Копирование ширины и высоты ячеек
        for i, column in enumerate(source_sheet.columns, start=1):
            new_sheet.column_dimensions[get_column_letter(i)].width = source_sheet.column_dimensions[
                get_column_letter(i)].width

        for row in source_sheet.rows:
            new_sheet.row_dimensions[row[0].row].height = source_sheet.row_dimensions[row[0].row].height

        # Копирование стилей из последней строки
        last_row = source_sheet.max_row
        for col in range(1, source_sheet.max_column + 1):
            new_sheet.cell(row=last_row + 1, column=col)._style = copy(
                source_sheet.cell(row=last_row, column=col)._style)

        # Добавление новой строки для полной нагрузки
        new_sheet.cell(row=last_row + 1, value='Полная нагрузка', column=1)
        for col in range(2, source_sheet.max_column + 1):
            new_sheet.cell(row=last_row + 1, column=col)._style = copy(
                source_sheet.cell(row=last_row, column=col)._style)