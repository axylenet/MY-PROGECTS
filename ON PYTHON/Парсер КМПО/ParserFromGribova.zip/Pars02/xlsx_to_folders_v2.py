''' Гаврюшкин Максим 21ИС-21
Код импортирует модуль openpyxl для работы с файлами Excel
'''
import openpyxl
import os

'''
Затем открываем конкретный файл и выбирает лист "ПланСвод".
'''
workbook = openpyxl.load_workbook('ИСиП_П_09.02.07_2023_1234.plx.xlsx')
worksheet = workbook['ПланСвод']

'''
Далее определяется переменная core_dir, которая будет использоваться для создания директорий. 
Если эта директория не существует, она создается с помощью функции os.mkdir().
'''
core_dir = "ОП.ОБЩ"

if not os.path.exists(core_dir):
    os.mkdir(core_dir)
path1 = ""

'''
Затем начинается цикл, который обходит все ряды первых трех колонок. 
Для каждой ячейки в ряду определяются соответствующие переменные cell1, cell2 и cell3.
'''
for row in range(1, worksheet.max_row+1):
    cell1 = worksheet.cell(row=row, column=1)
    cell2 = worksheet.cell(row=row, column=2)
    cell3 = worksheet.cell(row=row, column=3)

    if cell1.value != None and cell1.value != "+" and cell1.value != "-": # Если значение ячейки cell1 не равно None, "+" или "-", то создается новая директория с именем, указанным в этой ячейке.
        path = f"{core_dir}/{cell1.value.strip()}"
        path1 = path
        if not os.path.exists(path): # Если директория уже существует, то она не создается заново.
            os.mkdir(path)
        print(cell1.value)
    elif cell2.value != None:
        # Проверяем, является ли шрифт жирным
        if cell3.font.bold: # Если да, то создается новая директория с именем, составленным из значений ячеек cell2 и cell3.
            path1 = f"{path}/{cell2.value.strip()} {cell3.value.strip()}"
            if not os.path.exists(path1):
                os.mkdir(path1)
            print(path1)    
        else: # Если шрифт не жирный, то создается новая директория с именем, составленным из значений ячеек cell2 и cell3, но уже внутри предыдущей директории.
            path2 = f"{path1}/{cell2.value.strip()} {cell3.value.strip()}"    
            if not os.path.exists(path2):
                os.mkdir(path2)
            print(path2) # В конце каждой итерации цикла выводится на экран имя созданной директории
